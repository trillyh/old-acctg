from django.contrib import admin
from .models import JournalEntry

admin.site.register(JournalEntry)
# Register your models here.
